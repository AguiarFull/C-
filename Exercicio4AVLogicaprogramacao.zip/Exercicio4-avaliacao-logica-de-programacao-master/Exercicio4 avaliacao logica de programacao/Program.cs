﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio4_avaliacao_logica_de_programacao
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Utilizando estrutura FOR, escrever um programa para exibir os números de 1 até 50 na tela.


            for (int i = 1; i <= 50; i++)
                Console.WriteLine(i);
            Console.ReadKey();
        }
    }
}
